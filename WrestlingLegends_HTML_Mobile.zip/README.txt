Wrestling Legends HTML Mobile Version

Instructions:
1. Upload the entire folder to your itch.io private page.
2. Mark 'index.html' as the playable file in browser.
3. Make sure 'assets', 'scripts', and 'sounds' folders are included.
4. Touch controls will work on mobile when full game logic is added.
